package it.volta.ts.easymask.tools;

public class ToolSelector {
    public static int toolState = 1; //0 - Eraser; 1 - Brush
}

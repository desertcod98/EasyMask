package it.volta.ts.easymask.networking;

public class Response1 {

}

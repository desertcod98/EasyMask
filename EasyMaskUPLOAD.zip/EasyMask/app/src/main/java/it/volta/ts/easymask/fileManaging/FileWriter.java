package it.volta.ts.easymask.fileManaging;

import android.content.Context;

import java.io.File;

public class FileWriter {
    /*Context context;
    final String tempFolderName = "temp";

    public void TEMPWriteToFile(){
        File dir = new File(context.getFilesDir(), tempFolderName);
        if(!dir.exists()){
            dir.mkdir();
        }

        Writer writer;

        try {
            File gpxfile = new File(dir, "sus.txt");
            java.io.FileWriter writer = new java.io.FileWriter(gpxfile);
            writer.append("lol");
            writer.flush();
            writer.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }*/

}
